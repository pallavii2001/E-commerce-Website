import logo from './logo.svg';
import './App.css';
import Navbar from './Components/Navbar/Navbar';
import Routerindex from '../src/Router/index'


function App() {
  return (
   <div>
    <Navbar/>
      <Routerindex />
    
   </div>
  );
}

export default App;
