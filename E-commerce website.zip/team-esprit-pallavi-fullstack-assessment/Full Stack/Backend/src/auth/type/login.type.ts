export type LoginUserTypes = {
    email : string,
    password: string
} 