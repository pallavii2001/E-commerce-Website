export type CreateUserTypes = {
    Name: string,
    email: string,
    password: string,
    Address:string,
}